# QA Testing Portfolio

Hands-on QA portfolio covering REST API testing, Postman/Newman automation, UI regression, SQL data checks, and CI with GitHub Actions. The repository contains runnable source files (no archive extraction required).

## Projects

### Restful Booker API testing

The [public Postman documentation](https://documenter.getpostman.com/view/59042488/2sBYHSxg8z) and checked-in collection `postman/restful-booker.collection.json` cover a sequential CRUD flow against the public [Restful Booker demo API](https://restful-booker.herokuapp.com/): authentication, booking creation, read, update, and deletion. It stores the token and booking ID automatically, validates response status, JSON fields and data types, checks unauthorized and invalid-ID cases, and confirms the booking is absent after deletion. Boundary and observed validation behavior are documented in the collection and [test cases](reports/test-cases.md).

An independently runnable Python suite uses `pytest`, `requests`, and JSON Schema validation for positive, negative, unauthorized, and boundary scenarios. It creates test data dynamically and cleans it up.

### SauceDemo UI smoke test

A Playwright test covers login, adding a product to the cart, checkout, and order confirmation using SauceDemo's public training account.

### SQL examples and test documentation

`sql/order_consistency_checks.sql` contains illustrative checks for common order data inconsistencies. The public training store does not expose a database, so these queries are examples for a conventional test schema. Test cases and exploratory notes are in `reports/`.

## Run locally

Requirements: Python 3.12+, Node.js 22+, pnpm, and Chromium for the UI suite.

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\\Scripts\\activate
python -m pip install -r requirements.txt
python -m playwright install chromium
pnpm install --frozen-lockfile
mkdir -p artifacts
```

Run the suites independently:

```bash
python -m pytest api_tests -m api
pnpm test:postman
python -m pytest ui_tests -m ui
```

Import `postman/restful-booker.collection.json` into Postman to run or inspect the collection. The exported environment file is optional; the collection has its public base URL and demo credentials configured for this training API.

## CI

GitHub Actions runs the Python API tests, Newman collection, and Playwright UI smoke test on pushes, pull requests, and manual dispatch. HTML/JUnit reports are uploaded as workflow artifacts.

## Scope and limitations

- These are public demo services; downtime, rate limits, or changed sample credentials can affect runs.
- The collection records observed behavior for malformed input on the demo API; see request names and test documentation for expected results. An observed server error is reported as behavior of the demo, not as a claim about a production API.
- SQL checks are illustrative because the training storefront has no accessible database.
- The OWASP Juice Shop exploratory check and its observed environment issue are documented in `reports/exploratory-check.md`.

## Skills demonstrated

Postman, Newman, REST API, HTTP, JSON, Python, pytest, requests, JSON Schema, Playwright, SQL, GitHub Actions, test design, boundary-value testing, and test data setup/cleanup.
